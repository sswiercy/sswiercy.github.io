#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>


typedef struct Vector {
	int x;
	int y;
} Vector;

typedef int(*Direction)(const Vector*);

typedef struct Cluster Cluster;

struct Cluster {
	Cluster* leader;
	Cluster* next;
};

typedef struct Vertex Vertex;

struct Vertex {
	Vertex* next;
	Cluster cluster;
	Vector position;
	int weight;
	int degree;
};

typedef struct Edge Edge;

typedef struct Conflict Conflict;

struct Edge {
	Edge* next;
	Vertex* vertex[2];
	Conflict* conflicts;
	int weight;
	int blocked;
};

struct Conflict {
	Conflict* next;
	Edge* edge;
};

typedef struct Grid {
	int cols;
	int rows;
	char* buffer;
} Grid;


static const int max_weight = 2;
static const int col_delta = 4;
static const int row_delta = 2;
static const char edge_chars[] = { ' ', '+', '#' };

static Vertex* vertices = NULL;
static Edge* edges = NULL;

static size_t cluster_count = 0;


static void read_vertices(void) {
	Vertex** tail = &vertices;
	Vector size;
	Vector position;

	if (scanf("%d %d", &size.x, &size.y) < 2) {
		puts("Failed to read grid size");
		exit(EXIT_FAILURE);
	}

	for (position.y = 0; position.y < size.y; ++position.y) {
		for (position.x = 0; position.x < size.x; ++position.x) {
			int weight;

			if (scanf("%d", &weight) < 1 || weight < 0) {
				puts("Failed to read weight");
				exit(EXIT_FAILURE);
			}

			if (weight) {
				Vertex* vertex = malloc(sizeof(Vertex));

				vertex->next = NULL;
				vertex->cluster.leader = &vertex->cluster;
				vertex->cluster.next = NULL;
				vertex->position = position;
				vertex->weight = weight;
				vertex->degree = 0;

				++cluster_count;

				*tail = vertex;
				tail = &vertex->next;
			}
		}
	}
}

static int direction_x(const Vector* vector) {
	return vector->x;
}

static int direction_y(const Vector* vector) {
	return vector->y;
}

static Vertex* find_vertex(
	const Vertex* vertex, Direction dir_long, Direction dir_lat
) {
	Vertex* result = NULL;
	Vertex* current = vertices;

	while (current) {
		if (dir_lat(&current->position) == dir_lat(&vertex->position) &&
			dir_long(&current->position) > dir_long(&vertex->position) &&
			(!result || dir_long(&current->position) <
				dir_long(&result->position))) {
			result = current;
		}
		current = current->next;
	}

	return result;
}

static Vertex* find_horizontal(const Vertex*vertex) {
	return find_vertex(vertex, direction_x, direction_y);
}

static Vertex* find_vertical(const Vertex*vertex) {
	return find_vertex(vertex, direction_y, direction_x);
}

static void append_edge(Vertex* first, Vertex* second, Edge*** tail) {
	if (second) {
		Edge* edge = malloc(sizeof(Edge));

		edge->next = NULL;
		edge->vertex[0] = first;
		edge->vertex[1] = second;
		edge->conflicts = NULL;
		edge->blocked = 0;

		++first->degree;
		++second->degree;
		
		**tail = edge;
		*tail = &edge->next;
	}
}

static void create_edges(void) {
	Edge** tail = &edges;
	Vertex* vertex = vertices;
	
	while (vertex) {
		append_edge(vertex, find_horizontal(vertex), &tail);
		append_edge(vertex, find_vertical(vertex), &tail);
		vertex = vertex->next;
	}
}

static int do_conflict(const Edge* first, const Edge* second) {
	return first->vertex[0]->position.x < second->vertex[1]->position.x
		&& first->vertex[0]->position.y < second->vertex[1]->position.y
		&& first->vertex[1]->position.x > second->vertex[0]->position.x
		&& first->vertex[1]->position.y > second->vertex[0]->position.y;
}

static void create_edge_conflicts(Edge* edge) {
	Conflict** tail = &edge->conflicts;
	Edge* current = edge;
	
	while (current) {
		if (do_conflict(edge, current)) {
			Conflict* conflict = malloc(sizeof(Conflict));
			
			conflict->next = NULL;
			conflict->edge = current;

			*tail = conflict;
			tail = &conflict->next;
		}
		current = current->next;
	}
}

static void create_conflicts(void) {
	Edge* edge = edges;
	while (edge) {
		create_edge_conflicts(edge);
		edge = edge->next;
	}
}

static Cluster* join_clusters(const Edge* edge) {
	Cluster* first = &edge->vertex[0]->cluster;
	Cluster* second = &edge->vertex[1]->cluster;

	if (first->leader != second->leader) {
		Cluster* leader = first->leader;
		
		while (first->next) {
			first = first->next;
		}
		
		first->next = second;
		
		while (second) {
			second->leader = leader;
			second = second->next;
		}

		--cluster_count;
		assert(cluster_count > 0);
		return first;
	}

	return NULL;
}

static void split_cluster(Cluster* cluster) {
	Cluster* leader = cluster->next;
	cluster->next = NULL;
	cluster = leader;

	while (cluster) {
		cluster->leader = leader;
		cluster = cluster->next;
	}

	++cluster_count;
}

static int is_satisfiable(const Vertex* vertex) {
	return vertex->weight <= 2 * vertex->degree;
}

static void increment_degree(const Edge* edge) {
	++edge->vertex[0]->degree;
	++edge->vertex[1]->degree;
}

static int decrement_degree(const Edge* edge) {
	assert(edge->vertex[0]->degree);
	assert(edge->vertex[1]->degree);

	--edge->vertex[0]->degree;
	--edge->vertex[1]->degree;

	if (!is_satisfiable(edge->vertex[0]) ||
		!is_satisfiable(edge->vertex[1])) {

		increment_degree(edge);
		return 0;
	}

	return 1;
}

static void rollback_conflicts(Edge* edge, Conflict* conflict, int blocked) {
	Conflict* current = edge->conflicts;

	while (current != conflict) {
		Edge* other = current->edge;

		if (!other->blocked) {
			const int dec = decrement_degree(other);
			assert(dec);
		}
		
		other->blocked -= blocked;

		if (!other->blocked) {
			increment_degree(other);
		}

		current = current->next;
	}
}

static int update_conflicts(Edge* edge, int blocked) {
	Conflict* current = edge->conflicts;
	assert(blocked);

	while (current) {
		Edge* other = current->edge;

		if (!other->blocked && !decrement_degree(other)) {
			rollback_conflicts(edge, current, blocked);
			return 0;
		}
		
		other->blocked += blocked;
		assert(other->blocked >= 0);
		
		if (!other->blocked) {
			increment_degree(other);
		}

		current = current->next;
	}

	return 1;
}

static int increment_weight(Edge* edge) {
	if (edge->weight < max_weight &&
		edge->vertex[0]->weight &&
		edge->vertex[1]->weight) {

		--edge->vertex[0]->weight;
		--edge->vertex[1]->weight;
		++edge->weight;
		return 1;
	}

	return 0;
}

static void reset_weight(Edge* edge) {
	edge->vertex[0]->weight += edge->weight;
	edge->vertex[1]->weight += edge->weight;
}

static int enough_bridges(Edge* edge) {
	size_t count = 1;
	
	while (edge) {
		if (!edge->blocked &&
			edge->vertex[0]->cluster.leader !=
			edge->vertex[1]->cluster.leader &&
			++count >= cluster_count) {
			return 1;
		}
		edge = edge->next;
	}

	return 0;
}

static void check_isolated(void) {
	const Vertex* vertex = vertices;
	while (vertex) {
		if (!vertex->degree) {
			printf(
				"vertex (%d, %d) is isolated",
				vertex->position.x,
				vertex->position.y
			);
			exit(EXIT_FAILURE);
		}
		vertex = vertex->next;
	}
}

static int solve(Edge* edge) {
	if (!edge) {
		return cluster_count == 1;
	}

	if (!enough_bridges(edge)) {
		return 0;
	}

	edge->weight = 0;

	if (edge->blocked) {
		return solve(edge->next);
	}

	if (decrement_degree(edge)) {
		if (solve(edge->next)) {
			return 1;
		}
		if (!increment_weight(edge)) {
			increment_degree(edge);
			return 0;
		}
	} else {
		do {
			if (!increment_weight(edge)) {
				reset_weight(edge);
				return 0;
			}
		} while (!decrement_degree(edge));
	}

	if (update_conflicts(edge, 1)) {
		Cluster* cluster = join_clusters(edge);
		int updated;

		do {
			if (solve(edge->next)) {
				reset_weight(edge);
				return 1;
			}
		} while (increment_weight(edge));

		updated = update_conflicts(edge, -1);
		assert(updated);

		if (cluster) {
			split_cluster(cluster);
		}
	}

	reset_weight(edge);
	increment_degree(edge);
	return 0;
}

static void print_text(void) {
	const Edge* edge = edges;
	while (edge) {
		if (edge->weight) {
			printf(
				"(%d, %d) <-> (%d, %d): %d\n",
				edge->vertex[0]->position.x,
				edge->vertex[0]->position.y,
				edge->vertex[1]->position.x,
				edge->vertex[1]->position.y,
				edge->weight
			);
		}
		edge = edge->next;
	}
}

static void compute_grid_size(Vector* size) {
	const Vertex* vertex = vertices;

	size->x = -1;
	size->y = -1;

	while (vertex) {
		if (size->x < vertex->position.x) {
			size->x = vertex->position.x;
		}
		if (size->y < vertex->position.y) {
			size->y = vertex->position.y;
		}
		vertex = vertex->next;
	}

	++size->x;
	++size->y;
}

static void create_grid(Grid* grid) {
	Vector size;
	compute_grid_size(&size);

	grid->cols = col_delta * (size.x - 1) + 2;
	grid->rows = row_delta * (size.y - 1) + 1;
	grid->buffer = malloc(grid->cols * grid->rows + 1);
}

static char* grid_buf(const Grid* grid, int col, int row) {
	return grid->buffer + (row * grid->cols + col);
}

static void clear_grid(const Grid* grid) {
	int i;
	memset(grid->buffer, ' ', grid->cols * grid->rows);
	for (i = 0; i < grid->rows; ++i) {
		*grid_buf(grid, grid->cols - 1, i) = '\n';
	}
	grid->buffer[grid->cols * grid->rows] = '\0';
}

static void print_vertices(const Grid* grid) {
	const Vertex* vertex = vertices;
	while (vertex) {
		*grid_buf(
			grid,
			vertex->position.x * col_delta,
			vertex->position.y * row_delta
		) = '0' + vertex->weight;
		vertex = vertex->next;
	}
}

static void print_edges(const Grid* grid) {
	const Edge* edge = edges;

	while (edge) {
		if (edge->weight) {
			const Vector* begin = &edge->vertex[0]->position;
			const Vector* end = &edge->vertex[1]->position;

			Vector current;
			Vector previous;
			int index = 0;

			for (current.x = begin->x; current.x <= end->x; ++current.x) {
				for (current.y = begin->y; current.y <= end->y; ++current.y) {
					if (index) {
						const int col_prev = previous.x * col_delta;
						const int row_prev = previous.y * row_delta;
						const int col_cur = current.x * col_delta;
						const int row_cur = current.y * row_delta;
						const int col_mid = (col_prev + col_cur) / 2;
						const int row_mid = (row_prev + row_cur) / 2;

						*grid_buf(grid, col_mid, row_mid) =
							edge_chars[edge->weight];
						if (index > 1) {
							*grid_buf(grid, col_prev, row_prev) =
								edge_chars[edge->weight];
						}
					}

					previous = current;
					++index;
				}
			}
		}

		edge = edge->next;
	}
}

static void print_visual(void) {
	Grid grid;

	create_grid(&grid);
	clear_grid(&grid);
	print_vertices(&grid);
	print_edges(&grid);

	fputs(grid.buffer, stdout);
	free(grid.buffer);
}

int main(void) {
	const clock_t before = clock();

	read_vertices();
	create_edges();
	create_conflicts();
	check_isolated();
	
	if (solve(edges)) {
		print_text();
		puts("");
		print_visual();
	} else {
		puts("no solution found");
	}

	printf("\nruntime: %gs\n", (double) (clock() - before) / CLOCKS_PER_SEC);
	return EXIT_SUCCESS;
}
