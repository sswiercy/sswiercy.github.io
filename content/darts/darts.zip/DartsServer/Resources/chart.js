function adjustSize() {
	const width = window.innerWidth;
	const height = window.innerHeight - document.getElementsByTagName("div")[0].offsetHeight;
	const svg = document.getElementsByTagName("svg")[0];
	
	svg.style.height = Math.min(width, height) + "px";
	svg.style.display = "inline";
}

window.onload = adjustSize;
window.onresize = adjustSize;
