function getScopeSelect() {
	return document.getElementById("scope-select");
}

function getIndexSelect() {
	return document.getElementById("index-select");
}

function submitForm() {
	document.getElementsByTagName("form")[0].submit();
}

function submitScope() {
	const indexSelect = getIndexSelect();
	if (indexSelect) {
		indexSelect.disabled = true;
	}
	const scopeSelect = getScopeSelect();
	if (scopeSelect.selectedIndex == 0) {
		scopeSelect.disabled = true;
	}
	submitForm();
}

function submitIndex() {
	const indexSelect = getIndexSelect();
	if (indexSelect.selectedIndex == 0) {
		indexSelect.disabled = true;
	}
	submitForm();
}
