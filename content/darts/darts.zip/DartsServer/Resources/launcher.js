window.onload = function() {
	
	const storagePrefix = "darts-launcher-";
	
	const fieldIds = [
		"com-port",
		"score",
		"mode",
		"1st-player",
		"2nd-player",
		"3rd-player",
		"4th-player",
		"5th-player",
		"6th-player",
		"7th-player",
		"8th-player",
		"9th-player"
	];

	function storeField(field) {
		window.localStorage.setItem(storagePrefix + field, document.getElementById(field).value);
	}

	function restoreField(field) {
		const value = window.localStorage.getItem(storagePrefix + field);
		if (value !== null) {
			document.getElementById(field).value = value;
		}
	}

	function storeAllFields() {
		fieldIds.forEach(storeField);
	}

	function restoreAllFields() {
		document.forms[0].onsubmit = storeAllFields;
		fieldIds.forEach(restoreField);
	}
	
	restoreAllFields();
};
