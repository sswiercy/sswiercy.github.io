const defaultValues = {
	"com-port": "",
	"score": "301",
	"mode": "single",
	"1st-player": "",
	"2nd-player": "",
	"3rd-player": "",
	"4th-player": "",
	"5th-player": "",
	"6th-player": "",
	"7th-player": "",
	"8th-player": "",
	"9th-player": ""
};

function setCookie(key, value) {
	var date = new Date();
	date.setTime(date.getTime() + 365 * 24 * 60 * 60 * 1000);
	document.cookie = encodeURIComponent(key) + "=" + encodeURIComponent(value) + "; expires=" + date.toUTCString();
}

function getCookie(key) {
	const cookies = document.cookie.split(";");
	for (var i = 0; i < cookies.length; i++) {
		const index = cookies[i].indexOf("=");
		if (index >= 0 && decodeURIComponent(cookies[i].substring(0, index).trim()) === key) {
			return decodeURIComponent(cookies[i].substring(index + 1).trim());
		}
	}
	return null;
}

function storeField(field) {
	setCookie(field, document.getElementById(field).value);
}

function restoreField(field) {
	const value = getCookie(field);
	document.getElementById(field).value = value !== null ? value : defaultValues[field];
}

function storeAllFields() {
	for (let field in defaultValues) {
		storeField(field);
	}
}

function restoreAllFields() {
	document.forms[0].onsubmit = storeAllFields;
	for (let field in defaultValues) {
		restoreField(field);
	}
}

window.onload = restoreAllFields;
