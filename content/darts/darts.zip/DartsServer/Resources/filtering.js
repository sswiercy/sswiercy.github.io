window.onload = function() {
	Array.prototype.forEach.call(
		document.getElementsByTagName("form"),
		function(form) {
			const selects = form.getElementsByTagName("select");
			Array.prototype.forEach.call(
				selects,
				function(select, index) {
					select.onchange = function() {
						for (let i = index + 1; i < selects.length; i++) {
							selects[i].disabled = true;
						}
						if (!select.selectedIndex) {
							select.disabled = true;
						}
						form.submit();
					};
				}
			);
		}
	);
};
