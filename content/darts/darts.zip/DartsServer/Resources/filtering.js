window.onload = function() {
	Array.prototype.forEach.call(
		document.getElementsByTagName("form"),
		function(form) {
			const selects = form.getElementsByTagName("select");
			
			function storageKey(select) {
				return "darts-" + form.id + "-" + select.name;
			}
			
			function disableSelect(select) {
				window.localStorage.removeItem(storageKey(select));
				select.disabled = true;
			}
			
			Array.prototype.forEach.call(
				selects,
				function(select, index) {
					const value = window.localStorage.getItem(storageKey(select));

					if (value !== null && select.value != value) {
						Array.prototype.forEach.call(
							select.options,
							function(option) {
								if (option.value == value) {
									option.selected = true;
									form.submit();
								}
							}
						);
					}
					
					select.onchange = function() {
						if (!select.selectedIndex) {
							disableSelect(select);
						} else {
							window.localStorage.setItem(storageKey(select), select.value);
						}
						
						for (let i = index + 1; i < selects.length; i++) {
							disableSelect(selects[i]);
						}
						
						form.submit();
					};
				}
			);
		}
	);
};
