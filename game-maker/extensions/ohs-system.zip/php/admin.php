<?php

session_start();

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">

<html>

<head>

<title>OHS-System - Administration</title>

<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">

<link rel="stylesheet" type="text/css" href="format.css">

</head>

<body>

<div class="head">

<h1>OHS - System</h1>
<hr>
<h2>Administration</h2>

</div>

<div class="main">

<?php

include "file.php";
include "function.php";

slashes();

if (login_out()) {

echo "<div class=\"topmenu\">
<div class=\"topselect\">
<label>Anzeigen :</label>
";
$sel = select_out(array("mode","tables","Tabellen","types","Typen","functions","Funktionen","changepw","Passwort &auml;ndern"));
echo "</div>
<div class=\"logout\">
";
logout_out();
echo "</div>
</div>
";

switch ($sel) {
  
  case 0 :
    
    table_out();
    
    break;
    
  case 1 :
    
    type_out();
    
    break;
  
  case 2 :
    
    echo "<div class=\"topmenu\">
<div class=\"formrow\">
<label>Funktionstyp :</label>
";
    $sel = select_out(array("type","filter","Filter","show","Anzeige","auto","automatischer Wert","comp","Vergleich"),array("mode"));
    echo "</div>
";
    switch ($sel) {
      
      case 0 :
        
        function_out("filter",".filter");
        
        break;
      
      case 1 :
        
        function_out("show",".show");
        
        break;
      
      case 2 :
        
        function_out("auto",".auto");
        
        break;
      
      case 3 :
        
        function_out("comp",".comp");
        
        break;
      
    }
    
    break;
  
  case 3 :
    
    change_passw();
    
    break;
  
}

}

?>

</div>

<div class="copyright">
� 2008 - <a class="crlink" href="http://blackspark.bplaced.net" target="_blank">blackspark.bplaced.net</a>
</div>

</body>

</html>