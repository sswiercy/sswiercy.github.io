<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">

<html>

<head>

<title>Online Highscore</title>

<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">

<link rel="stylesheet" type="text/css" href="format.css">

</head>

<body>

<table class="highscore">
<tr>
<td>

<?php

include "file.php";
include "function.php";

if (isset($_GET["name"])) {
  $_GET["name"] = basename($_GET["name"]);
  if (!is_file("table/".$_GET["name"].".table") || ($data = db_read_file("table/".$_GET["name"].".table")) === false) {
    echo "<div class=\"highscorebox\">
<div class=\"errorboxhs\">
Die angegebene Tabelle existiert nicht!
</div>
</div>

";
  } else {
    echo "<div class=\"highscorebox\">
<h1>".htmlentities($_GET["name"])."</h1>
<hr>
<h2>Online Highscore</h2>
</div>

<div class=\"highscorebox\">
";
    $check = true;
    if (!check_table($data,false)) {
      $check = false;
    }
    $type = array();
    for ($i = 0; $i < $data["columns"]; $i++) {
      $type[$i] = db_read_file("type/".$data["type".$i].".type");
      if ($check && !check_type($type[$i],false)) {
        $check = false;
      }
    }
    if (!$check) {
      echo "<div class=\"errorboxhs\">
Die Tabelle ist fehlerhaft!
</div>

";
    } else {
      $code = load_codes($type,$data);
      
      echo "<table class=\"hstab\">
<tr>";
      for ($i = 0; $i < $data["columns"]; $i++) {
        echo "<td class=\"hshead\">".$data["col".$i]."</td>";
      }
      echo "</tr>
";
      
      $n = count($data["table"]);
      if ($n == 0) {
        echo "<tr><td class=\"tdnocontent\" colspan=\"".$data["columns"]."\">keine Eintr&auml;ge</td></tr>
";
      }
      for ($i = 0; $i < $n; $i++) {
        echo "<tr>";
        for ($j = 0; $j < $data["columns"]; $j++) {
          $row = $i+1;
          $value = $data["table"][$i][$j];
          echo "<td class=\"hscontent\">".htmlentities(eval($code[$j]))."</td>";
        }
        echo "</tr>
";
      }
      echo "</table>
";
    }
    echo "</div>

";
  }
} else {
  echo "<div class=\"highscorebox\">
<div class=\"errorboxhs\">
Keine Tabelle angegeben!
</div>
</div>

";
}

?>
<div class="hscopyright">
� 2008 - <a class="crlink" href="http://blackspark.bplaced.net" target="_blank">blackspark.bplaced.net</a>
</div>

</td>
</tr>
</table>

</body>

</html>