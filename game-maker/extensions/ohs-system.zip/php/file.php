<?php

function db_write_file($db,$a) {
  if (($h = @fopen($db,"wb")) !== false) {
    db_write_array($h,$a);
    fclose($h);
    return true;
  }
  else
    return false;
}

function db_write_array($h,$a) {
  bin_write_int($h,count($a)+1);
  foreach ($a as $i => $v) {
    $l = strlen($i);
    bin_write_int($h,$l);
    fwrite($h,$i,$l);
    if (is_array($a[$i]))
      db_write_array($h,$a[$i]);
    else {
      bin_write_int($h,0);
      $l = strlen($v);
      bin_write_int($h,$l);
      fwrite($h,$v,$l);
    }
  }
}

function db_read_file($db) {
  if (!is_file($db))
    return array();
  if (($h = @fopen($db,"rb")) !== false) {
    if (feof($h))
      return array();
    $ret = db_read_array($h,bin_read_int($h)-1);
    fclose($h);
    return $ret;
  }
  else
    return false;
}

function db_read_array($h,$l) {
  $a = array();
  for ($i = 0; $i < $l; $i++) {
    if (($rl = bin_read_int($h)) != 0)
      $j = fread($h,$rl);
    else
      $j = "";
    $t = bin_read_int($h);
    if ($t == 0) {
      if (($rl = bin_read_int($h)) != 0)
        $a[$j] = fread($h,$rl);
      else
        $a[$j] = "";
    }
    else
      $a[$j] = db_read_array($h,$t-1);
  }
  return $a;
}

function bin_read_int($h) {
  $l = ord(fread($h,1));
  $f = pow(256,$l);
  $s = 0;
  while ($f != 1) {
    $f /= 256;
    $s += ord(fread($h,1))*$f;
  }
  return $s;
}

function bin_write_int($h,$int) {
  $l = 0;
  $f = 1;
  while ($int >= $f) {
    $l++;
    $f *= 256;
  }
  fwrite($h,chr($l));
  $r = $int;
  while ($f != 1) {
    $f /= 256;
    fwrite($h,chr(floor($r/$f)));
    $r = $r%$f;
  }
}

?>