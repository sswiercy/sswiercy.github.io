<?php

function option_out($type_name,$value_name,$value) {
  echo "<option value=\"".htmlentities($value_name)."\"";
  if (isset($_GET[$type_name]) && $_GET[$type_name] === $value_name) {
    echo " selected";
    $ret = true;
  } else {
    $ret = false;
  }
  echo ">".$value."</option>
";
  return $ret;
}

function submit_out(&$submit) {
  if (SID != "") {
    echo "<input type=\"hidden\" name=\"".session_name()."\" value=\"".session_id()."\">
";
  }
  if (is_array($submit)) {
    foreach ($submit as $v) {
      if (isset($_GET[$v])) {
        echo "<input type=\"hidden\" name=\"".$v."\" value=\"".htmlentities($_GET[$v])."\">
";
      }
    }
  }
}

function select_out($data,$submit = NULL) {
  $n = count($data);
  if ($n < 1 || $n % 2 != 1) {
    return false;
  }
  
  echo "<form action=\"".basename($_SERVER["SCRIPT_NAME"])."\" method=\"get\">
";
  
  submit_out($submit);
  
  echo "<select class=\"selnorm\" name=\"".$data[0]."\" onchange=\"submit();\">
";
  
  $ret = 0;
  for ($i = 1; $i < $n; $i += 2) {
    if (option_out($data[0],$data[$i],$data[$i+1])) {
      $ret = ($i-1)/2;
    }
  }
  
  echo "</select>
<input class=\"buttonok\" type=\"submit\" value=\"OK\">
</form>
";
  
  return $ret;
}

function input_out($name,&$value) {
  $ret = false;
  if (isset($_GET[$name])) {
    $value = $_GET[$name];
    $ret = true;
  }
  echo "<input class=\"inputtext\" type=\"text\" name=\"".$name."\" id=\"".$name."\" value=\"".htmlentities($value)."\">
";
  return $ret;
}

function get_out(&$submit,$append) {
  $first = true;
  if (SID != "") {
    $append[session_name()] = session_id();
  }
  if (is_array($submit)) {
    $n = count($submit);
    for ($i = 0; $i < $n; $i++) {
      if (isset($_GET[$submit[$i]])) {
        if ($first) {
          echo "?";
        } else {
          echo "&amp;";
        }
        echo $submit[$i]."=".urlencode($_GET[$submit[$i]]);
        $first = false;
      }
    }
  }
  foreach ($append as $i => $v) {
    if ($first) {
      echo "?";
    } else {
      echo "&amp;";
    }
    echo $i."=".urlencode($v);
    $first = false;
  }
}

function delete_out(&$submit,&$file,$lable) {
  echo "<div class=\"divdelete\"><a class=\"abutton\" href=\"javascript:if (confirm('Wirklich l&ouml;schen?')) window.location.href = '";
  get_out($submit,array("delete" => $file));
  echo "';\">".$lable."</a></div>
";
}

function clear_out(&$submit,$lable) {
  echo "<a class=\"abutton\" href=\"javascript:if (confirm('Wirklich die Tabelle leeren?')) window.location.href = '";
  get_out($submit,array("clear" => "table"));
  echo "';\">".$lable."</a>
";
}

function order_out(&$submit,$lable) {
  echo "<a class=\"abutton\" href=\"";
  get_out($submit,array("order" => "table"));
  echo "\">".$lable."</a>
";
}

function delete_row_out(&$submit,$lable,$i) {
  echo "<div class=\"delrow\"><a class=\"abutton\" href=\"javascript:if (confirm('Wirklich den Eintrag l&ouml;schen?')) window.location.href = '";
  get_out($submit,array("delrow" => $i));
  echo "';\">".$lable."</a></div>
";
}

function &get_files($dir,$ext = "") {
  $data = array();
  if (!is_dir($dir)) {
    mkdir($dir);
  }
  $h = opendir($dir);
  while (($file = readdir($h)) !== FALSE) {
    if (is_file($dir."/".$file)) {
      if ($ext == "") {
        $data[] = $file;
      } else if (substr($file,-strlen($ext)) === $ext) {
        $data[] = substr($file,0,-strlen($ext));
      }
    }
  }
  closedir($h);
  return $data;
}

function array_double(&$data) {
  $n = count($data);
  for ($i = 0; $i < $n; $i += 2) {
    array_splice($data,$i,0,array($data[$i]));
    $n++;
  }
}

function edit_function($dir,$file,$ext,$submit = NULL) {
  echo "<form action=\"".basename($_SERVER["SCRIPT_NAME"])."";
  get_out($submit,array("func" => $file));
  echo "\" method=\"post\">
";
  
  $out = "";
  if (isset($_POST["contents"])) {
    if ($file == "") {
      error_out("Ung&uuml;ltiger Funktionsname!");
    } else {
      $h = @fopen($dir."/".$file.$ext,"wb");
      if ($h != NULL) {
        fwrite($h,$_POST["contents"],strlen($_POST["contents"]));
        fclose($h);
        confirm_out("Funktion gespeichert!");
      } else {
        error_out("Fehler beim speichern!");
      }
    }
    $out = htmlentities($_POST["contents"]);
  } else if ($file != "") {
    $n = filesize($dir."/".$file.$ext);
    if ($n > 0) {
      $h = @fopen($dir."/".$file.$ext,"rb");
      if ($h != NULL) {
        $out = htmlentities(fread($h,$n));
        fclose($h);
      } else {
        error_out("Fehler beim laden!");
      }
    }
  }
  
  echo "<div class=\"topmenu\">
<div class=\"topselect\">
<label for=\"name\">Name :</label>
<input class=\"inputtext\" type=\"text\" name=\"name\" id=\"name\" value=\"".htmlentities($file)."\">
<input class=\"button\" type=\"submit\" value=\"Speichern\">
</div>
<div class=\"logout\">
";
  
  if ($file != "") {
    delete_out($submit,$file,"Funktion l&ouml;schen");
  }
  
  echo "</div>
<div class=\"formrow\">
<label for=\"contents\">Script :</label>
<textarea class=\"funcedit\" name=\"contents\" id=\"contents\" rows=\"20\" cols=\"80\">".$out."</textarea>
</div>
</div>
</form>
";
}

function rename_file($dir,$ext,&$old,&$new,&$data) {
  if (!isset($old)) {
    $old = "";
  }
  if (isset($new) && $old !== $new) {
    $new = trim(basename($new));
    if ($new != "") {
      if (in_array($old,$data)) {
        if (@rename($dir."/".$old.$ext,$dir."/".$new.$ext)) {
          $old = $new;
          $data = get_files($dir,$ext);
        } else {
          return false;
        }
      } else if ($old === "") {
        $old = $new;
        $h = @fopen($dir."/".$old.$ext,"wb");
        if ($h == NULL) {
          $old = "";
          return false;
        } else {
          fclose($h);
          $data = get_files($dir,$ext);
        }
      }
    }
  }
  return true;
}

function delete_file($dir,$ext,&$data) {
  if (isset($_GET["delete"]) && in_array($_GET["delete"],$data)) {
    unlink($dir."/".$_GET["delete"].$ext);
    $data = get_files($dir,$ext);
  }
}

function slashes() {
  if (get_magic_quotes_gpc() == 1) {
    foreach ($_GET as $i => $v) {
      $_GET[$i] = stripslashes($v);
    }
    foreach ($_POST as $i => $v) {
      $_POST[$i] = stripslashes($v);
    }
  }
}

function function_out($dir,$ext) {
  $data = get_files($dir,$ext);
  
  rename_file($dir,$ext,$_GET["func"],$_POST["name"],$data);
  delete_file($dir,$ext,$data);
  
  array_double($data);
  array_splice($data,0,0,array("func","","&lt; Neue Funktion &gt;"));
  
  echo "<div class=\"formrow\">
<label>Funktion :</label>
";
  $filter = select_out($data,array("mode","type"));
  echo "</div>
</div>
";
  
  edit_function($dir,$data[$filter*2+1],$ext,array("mode","type"));
}

function function_list($dir,$ext,$name,$class) {
  $data = get_files($dir,$ext);
  
  echo "<select class=\"".$class."\" name=\"".$name."\">
";
  
  $n = count($data);
  $ret = false;
  if (option_out($name,"","&lt; keine &gt;")) {
    $ret = "";
  }
  for ($i = 0; $i < $n; $i++) {
    if (option_out($name,$data[$i],$data[$i])) {
      $ret = $data[$i];
    }
  }
  
  echo "</select>
";
  
  return $ret;
}

function select_list($name,$data,$class) {
  echo "<select class=\"".$class."\" name=\"".$name."\">
";
  $ret = false;
  $n = count($data);
  for ($i = 0; $i < $n; $i += 2) {
    if (option_out($name,$data[$i],$data[$i+1])) {
      $ret = $data[$i];
    }
  }
  echo "</select>
";
  return $ret;
}

function edit_type($file,$submit = NULL) {
  echo "<form action=\"".basename($_SERVER["SCRIPT_NAME"])."\" method=\"get\">
";
  
  submit_out($submit);
  
  echo "<input type=\"hidden\" name=\"type\" value=\"".htmlentities($file)."\">
<div class=\"topmenu\">
<div class=\"topselect\">
<label for=\"name\">Name :</label>
<input class=\"inputtext\" type=\"text\" name=\"name\" id=\"name\" value=\"".htmlentities($file)."\">
</div>
<div class=\"logout\">
";
  
  if ($file != "") {
    delete_out($submit,$file,"Typ l&ouml;schen");
  }
  
  echo "</div>
";

  $save = (isset($_GET["maintype"]) && isset($_GET["filter"]) && isset($_GET["show"]) && isset($_GET["auto"]) && isset($_GET["comp"]));
  $data = array();
  
  if (!$save && $file != "") {
    $data = db_read_file("type/".$file.".type");
    $_GET["maintype"] = $data["0"];
    $_GET["filter"] = $data["1"];
    $_GET["show"] = $data["2"];
    $_GET["auto"] = $data["3"];
    $_GET["comp"] = $data["4"];
  }
  
  echo "<div class=\"formrow\"><label>Art :</label>";
  $data["0"] = select_list("maintype",array("0","Daten mit &Uuml;bertragung","1","Daten ohne &Uuml;bertragung","2","keine Daten"),"selnorm");
  echo "</div>
";
  
  echo "<div class=\"formrow\"><label>Filter :</label>";
  $data["1"] = function_list("filter",".filter","filter","selnorm");
  echo "</div>
";
  echo "<div class=\"formrow\"><label>Anzeige :</label>";
  $data["2"] = function_list("show",".show","show","selnorm");
  echo "</div>
";
  echo "<div class=\"formrow\"><label>auto. Wert :</label>";
  $data["3"] = function_list("auto",".auto","auto","selnorm");
  echo "</div>
";
  echo "<div class=\"formrow\"><label>Vergleich :</label>";
  $data["4"] = function_list("comp",".comp","comp","selnorm");
  echo "</div>
";
  
  echo "<div class=\"formrow\"><label></label><input class=\"button\" type=\"submit\" value=\"Speichern\"></div>
</div>
</form>
";
  
  if ($save) {
    if ($data["0"] === false || $data["1"] === false || $data["2"] === false || $data["3"] === false || $data["4"] === false) {
      error_out("&Uuml;bertragungsfehler!");
      $data["0"] = 0;
      $data["1"] = "";
      $data["2"] = "";
      $data["3"] = "";
      $data["4"] = "";
    }
    if ($file == "" || !db_write_file("type/".$file.".type",$data)) {
      error_out("Ung&uuml;ltiger Typname!");
    } else {
      confirm_out("Typ gespeichert!");
    }
  }
  if ($file != "") {
    check_type($data,true);
  }
}

function type_out() {
  $data = get_files("type",".type");
  
  rename_file("type",".type",$_GET["type"],$_GET["name"],$data);
  delete_file("type",".type",$data);
  
  array_double($data);
  array_splice($data,0,0,array("type","","&lt; Neuer Typ &gt;"));
  
  echo "<div class=\"topmenu\">
<div class=\"formrow\">
<label>Typ :</label>
";
  $type = select_out($data,array("mode"));
  echo "</div>
</div>
";
  
  edit_type($data[$type*2+1],array("mode"));
}

function add_column(&$submit,&$file,&$data) {
  $change = false;
  if (isset($_GET["add"]) && $_GET["add"] === "column") {
    $data["col".$data["columns"]] = "";
    $data["type".$data["columns"]] = "";
    $data["sort".$data["columns"]] = 0;
    $data["columns"]++;
    $n = count($data["table"]);
    for ($j = 0; $j < $n; $j++) {
      array_push($data["table"][$j],"");
    }
    $change = true;
  }
  
  echo "<a class=\"abutton\" href=\"";
  get_out($submit,array("add" => "column"));
  echo "\">Spalte hinzuf&uuml;gen</a>
";
  return $change;
}

function exchange(&$v1,&$v2) {
  $t = $v1;
  $v1 = $v2;
  $v2 = $t;
}

function column_out(&$submit,&$file,&$data,&$i) {
  $change = false;
  
  if ((isset($_GET["upcol"]) && $_GET["upcol"] === (string)($i+1)) || (isset($_GET["downcol"]) && $_GET["downcol"] === (string)$i && $i < $data["columns"]-1)) {
    exchange($data["col".$i],$data["col".($i+1)]);
    exchange($data["type".$i],$data["type".($i+1)]);
    exchange($data["sort".$i],$data["sort".($i+1)]);
    exchange($_GET["type".$i],$_GET["type".($i+1)]);
    exchange($_GET["sort".$i],$_GET["sort".($i+1)]);
    $n = count($data["table"]);
    for ($j = 0; $j < $n; $j++) {
      exchange($data["table"][$j][$i],$data["table"][$j][$i+1]);
    }
    $change = true;
  }
  
  echo "<div class=\"topselect\">
<label for=\"col".$i."\">".($i+1).". Spalte :</label>
<input class=\"inputtext\" type=\"text\" name=\"col".$i."\" id=\"col".$i."\" value=\"".htmlentities($data["col".$i])."\">
";
  
  $new = function_list("type",".type","type".$i,"seltabtype");
  if ($new !== $data["type".$i]) {
    $data["type".$i] = $new;
    $change = true;
  }
  
  $sort = array("0","-");
  for ($j = 1; $j <= $data["columns"]; $j++) {
    $sort[] = (string)$j;
    $sort[] = (string)$j;
  }
  select_list("sort".$i,$sort,"seltabsort");
  
  echo "</div>
<div class=\"divtab\"><a class=\"abutton\" href=\"javascript:if (confirm('Wirklich l&ouml;schen?')) window.location.href = '";
  get_out($submit,array("delcol" => $i));
  echo "';\">L&ouml;schen</a></div>
";
  
  echo "<div class=\"divtab\"><a class=\"abutton\" href=\"";
  get_out($submit,array("upcol" => $i));
  echo "\">Hoch</a></div>
";
  
  echo "<div class=\"divtab\"><a class=\"abutton\" href=\"";
  get_out($submit,array("downcol" => $i));
  echo "\">Runter</a></div>
<div class=\"formrow\"></div>
";
  
  return $change;
}

function delete_row(&$data) {
  if (isset($_GET["delcol"]) && (string)($i = (int)$_GET["delcol"]) == $_GET["delcol"] && $i >= 0 && $i < $data["columns"]) {
    $data["columns"]--;
    $n = count($data["table"]);
    for ($j = 0; $j < $n; $j++) {
      array_splice($data["table"][$j],$i,1);
    }
    for ($j = $i; $j < $data["columns"]; $j++) {
      $data["col".$j] = $data["col".($j+1)];
      $data["type".$j] = $data["type".($j+1)];
      $data["sort".$j] = $data["sort".($j+1)];
      $_GET["type".$j] = $data["type".$j];
      $_GET["sort".$j] = $data["sort".$j];
    }
    unset($data["col".$data["columns"]]);
    unset($data["type".$data["columns"]]);
    unset($data["sort".$data["columns"]]);
    return true;
  }
  return false;
}

function edit_table($file,$submit = NULL) {
  echo "<form action=\"".basename($_SERVER["SCRIPT_NAME"])."\" method=\"get\">
";
  
  submit_out($submit);
  
  echo "<input type=\"hidden\" name=\"table\" value=\"".htmlentities($file)."\">
<div class=\"topmenu\">
<div class=\"topselect\">
<label for=\"name\">Name :</label>
<input class=\"inputtext\" type=\"text\" name=\"name\" id=\"name\" value=\"".htmlentities($file)."\">
<input class=\"button\" type=\"submit\" value=\"Speichern\">
</div>
<div class=\"logout\">
";
  
  if ($file != "") {
    delete_out($submit,$file,"Tabelle l&ouml;schen");
  }
  
  echo "</div>
";
  
  if ($file != "") {
    if ($submit == NULL) {
      $submit = array("table");
    } else {
      array_push($submit,"table");
    }
    
    $error = "";
    $change = false;
    $save = false;
    $data = db_read_file("table/".$file.".table");
    if (!isset($data["columns"])) {
      $data["columns"] = 0;
      $change = true;
    }
    if (!isset($data["passw"])) {
      $data["passw"] = "";
      $change = true;
    }
    if (!isset($data["numb"])) {
      $data["numb"] = 100;
      $change = true;
    }
    if (!isset($data["table"])) {
      $data["table"] = array();
      $change = true;
    }
    
    echo "<div class=\"formrow\"><label for=\"passw\">Passwort :</label>";
    if (input_out("passw",$data["passw"])) {
      $change = true;
    }
    echo "</div>
<div class=\"formrow\"><label for=\"numb\">max. Eintr&auml;ge :</label>";
    $old = $data["numb"];
    if (input_out("numb",$data["numb"])) {
      if ((string)(int)$data["numb"] === $data["numb"] && $data["numb"] > 0) {
        if ($data["numb"] < count($data["table"])) {
          array_splice($data["table"],$data["numb"]);
        }
        $change = true;
        $save = true;
      } else {
        $data["numb"] = $old;
        $error = "Ung&uuml;ltige Anzahl!";
      }
    }
    echo "</div>
";
  }
  
  echo "</div>
";
  
  if ($file != "") {
    chmod("table/".$file.".table",0600);
    
    echo "<div class=\"topmenu\">
<div class=\"formrow\">
<div class=\"divadd\">
";
    if (add_column($submit,$file,$data)) {
      $change = true;
    }
    echo "</div>
</div>
";
    
    if (delete_row($data)) {
      $change = true;
    }
    
    $files = get_files("type",".type");
    for ($i = 0; $i < $data["columns"]; $i++) {
      if (isset($_GET["col".$i]) && isset($_GET["type".$i]) && isset($_GET["sort".$i]) && ($_GET["type".$i] == "" || in_array($_GET["type".$i],$files)) && (string)(int)$_GET["sort".$i] == $_GET["sort".$i] && $_GET["sort".$i] >= 0 && $_GET["sort".$i] <= $data["columns"]) {
        $data["col".$i] = $_GET["col".$i];
        $data["type".$i] = $_GET["type".$i];
        $data["sort".$i] = $_GET["sort".$i];
        $change = true;
        $save = true;
      } else {
        $_GET["type".$i] = $data["type".$i];
        $_GET["sort".$i] = $data["sort".$i];
      }
    }
    
    for ($i = 0; $i < $data["columns"]; $i++) {
      if (column_out($submit,$file,$data,$i)) {
        $change = true;
      }
    }
    
    if (isset($_GET["clear"]) && $_GET["clear"] == "table") {
      $data["table"] = array();
      $change = true;
    }
    
    if (isset($_GET["delrow"]) && isset($data["table"][$_GET["delrow"]])) {
      array_splice($data["table"],$_GET["delrow"],1);
      $change = true;
    }
    
    if (isset($_GET["order"]) && $_GET["order"] == "table") {
      $type = array();
      for ($i = 0; $i < $data["columns"]; $i++) {
        $type[$i] = db_read_file("type/".$data["type".$i].".type");
      }
      
      $codes = get_codes($data,$type);
      
      $newdata = $data;
      $newdata["table"] = array();
      $n = count($data["table"]);
      for ($i = 0; $i < $n; $i++) {
        array_splice($newdata["table"],get_insert_row($newdata,$data["table"][$i],$codes),0,array($data["table"][$i]));
      }
      $data = $newdata;
      $change = true;
    }
    
    echo "</div>
";
    
    if ($error != "") {
      error_out($error);
    }
    
    if ($change) {
      if (db_write_file("table/".$file.".table",$data) && $save) {
        confirm_out("Tabelle gespeichert!");
      }
    }
    
    $ok = check_table($data,true);
  } else if (isset($_GET["name"])) {
    error_out("Ung&uuml;ltiger Tabellenname!");
  }
  
  echo "</form>
";
  
  if ($file != "" && $ok) {
    $type = array();
    $error = "<div>Von der Tabelle genutzte Typen sind fehlerhaft:</div>
";
    for ($i = 0; $i < $data["columns"]; $i++) {
      $type[$i] = db_read_file("type/".$data["type".$i].".type");
      if (!check_type($type[$i],false)) {
        $ok = false;
        $error .= "<div>Der Typ von Spalte ".($i+1)." ist fehlerhaft!</div>
";
      }
    }
    if ($ok) {
      echo "<div class=\"topmenu\">
<div class=\"divcenter\">
<div class=\"divtabclear\">
";
      clear_out($submit,"Tabelle leeren");
      echo "</div>
<div class=\"divtabsort\">
";
      order_out($submit,"Neu sortieren");
      echo "</div>
</div>
<div class=\"formrow\"></div>
</div>
<div class=\"tbldiv\">
<table class=\"tab\">
<tr>";
      for ($i = 0; $i < $data["columns"]; $i++) {
        echo "<td class=\"tdhead\">".$data["col".$i]."</td>";
      }
      echo "<td></td></tr>
";
      $n = count($data["table"]);
      if ($n == 0) {
        echo "<tr><td class=\"tdnocontent\" colspan=\"".$data["columns"]."\">keine Eintr&auml;ge</td></tr>
";
      }
      for ($i = 0; $i < $n; $i++) {
        echo "<tr>";
        for ($j = 0; $j < $data["columns"]; $j++) {
          $row = $i+1;
          $value = $data["table"][$i][$j];
          $h = fopen("show/".$type[$j]["2"].".show","rb");
          echo "<td class=\"tdcontent\">".htmlentities(eval(fread($h,filesize("show/".$type[$j]["2"].".show"))))."</td>";
          fclose($h);
        }
        echo "<td class=\"tddel\">";
        delete_row_out($submit,"Eintrag l&ouml;schen",$i);
        echo "</td></tr>
";
      }
        
      echo "</table>
</div>
";
    } else {
      error_out($error);
    }
  }
}

function table_out() {
  $data = get_files("table",".table");
  
  rename_file("table",".table",$_GET["table"],$_GET["name"],$data);
  delete_file("table",".table",$data);
  
  array_double($data);
  array_splice($data,0,0,array("table","","&lt; Neue Tabelle &gt;"));
  
  echo "<div class=\"topmenu\">
<div class=\"formrow\">
<label>Tabelle :</label>
";
  $table = select_out($data,array("mode"));
  echo "</div>
</div>
";
  
  edit_table($data[$table*2+1],array("mode"));
}

function check_type_auto(&$data,&$out) {
  if ($data["3"] == "" || !is_file("auto/".$data["3"].".auto")) {
    $out .= "<div>Bitte eine automatische Wertfunktion ausw&auml;hlen!</div>
";
    return false;
  }
  return true;
}

function check_type_show(&$data,&$out) {
  if ($data["2"] == "" || !is_file("show/".$data["2"].".show")) {
    $out .= "<div>Bitte eine Anzeigefunktion ausw&auml;hlen!</div>
";
    return false;
  }
  return true;
}

function check_type_comp(&$data,&$out) {
  if ($data["4"] == "" || !is_file("comp/".$data["4"].".comp")) {
    $out .= "<div>Bitte eine Vergleichsfunktion ausw&auml;hlen!</div>
";
    return false;
  }
  return true;
}

function check_type(&$data,$out = false) {
  $check = true;
  $output = "";
  switch ($data["0"]) {
    case 1 :
      $check = check_type_auto($data,$output) && $check;
    case 0 :
      $check = check_type_show($data,$output) && $check;
      $check = check_type_comp($data,$output) && $check;
      break;
    case 2 :
      $check = check_type_show($data,$output) && $check;
      break;
  }
  if (!$check) {
    $output = "<div>Dieser Typ ist fehlerhaft:</div>
".$output;
    if ($out) {
      error_out($output);
    }
  }
  return $check;
}

function check_table(&$data,$out = false) {
  $check = true;
  $output = "";
  $istype = array();
  for ($i = 0; $i < $data["columns"]; $i++) {
    $istype[$i] = !($data["type".$i] == "" || !is_file("type/".$data["type".$i].".type"));
    if (!$istype[$i]) {
      $check = false;
      $output .= "<div>Bitte bei Spalte ".($i+1)." einen Typ w&auml;hlen!</div>
";
    }
  }
  $find = 0;
  for ($i = 0; $i < $data["columns"]; $i++) {
    if ($istype[$i] && $data["sort".$i] != 0) {
      $type = db_read_file("type/".$data["type".$i].".type");
      if ($type["0"] == 2) {
        $check = false;
        $output .= "<div>Nach Spalte ".($i+1)." darf wegen des Typs nicht sortiert werden!</div>
";
      }
      $find++;
    }
  }
  if ($data["columns"] == 0) {
    $check = false;
    $output .= "<div>Die Tabelle muss mindestens eine Spalte enthalten!</div>
";
  } else if ($find == 0) {
    $check = false;
    $output .= "<div>Bitte mindestens eine Spalte zum sortieren w&auml;hlen!</div>
";
  } else {
    for ($j = 1; $j <= $data["columns"]; $j++) {
      $find = 0;
      for ($i = 0; $i < $data["columns"]; $i++) {
        if ($data["sort".$i] == $j) {
          $find++;
        }
      }
      if ($find > 1) {
        $check = false;
        $output .= "<div>Die Sortiernummer ".$j." darf nur einmal vorkommen!</div>
";
      }
    }
  }
  if (!$check) {
    $output = "<div>Diese Tabelle ist fehlerhaft:</div>
".$output;
    if ($out) {
      error_out($output);
    }
  }
  return $check;
}

function get_insert_ordered(&$data,$value) {
  $n = 0;
  $m = count($data);
  while ($m > $n) {
    $k = ($n+$m)>>1;
    if ($value > $data[$k]) {
      $n = $k+1;
    } else {
      $m = $k;
    }
  }
  return $n;
}

function &get_order(&$data) {
  $order_val = array();
  $order = array();
  for ($i = 0; $i < $data["columns"]; $i++) {
    if ($data["sort".$i] != 0) {
      $j = get_insert_ordered($order_val,$data["sort".$i]);
      array_splice($order_val,$j,0,array($data["sort".$i]));
      array_splice($order,$j,0,array($i));
    }
  }
  return $order;
}

function compare_row(&$row1,&$row2,&$data,&$code) {
  $order = get_order($data);
  $n = count($order);
  for ($i = 0; $i < $n; $i++) {
    $value1 = $row1[$order[$i]];
    $value2 = $row2[$order[$i]];
    if ($value1 !== $value2) {
      return eval($code[$order[$i]]);
    }
  }
  return false;
}

function get_insert_row(&$data,&$row,&$codes) {
  $n = 0;
  $m = count($data["table"]);
  while ($m > $n) {
    $i = ($n+$m)>>1;
    if (!compare_row($data["table"][$i],$row,$data,$codes)) {
      $n = $i+1;
    } else {
      $m = $i;
    }
  }
  return $n;
}

function &get_codes(&$data,&$type) {
  $codes = array();
  for ($i = 0; $i < $data["columns"]; $i++) {
    if ($type[$i]["0"] != 2) {
      $h = fopen("comp/".$type[$i]["4"].".comp","rb");
      $codes[$i] = fread($h,filesize("comp/".$type[$i]["4"].".comp"));
      fclose($h);
    }
  }
  return $codes;
}

function check_passw($pw) {
  $h = @fopen("password","rb");
  if ($h == NULL) {
    return true;
  } else {
    $check = (fread($h,filesize("password")) == md5($pw));
    fclose($h);
    return $check;
  }
}

function error_out($msg) {
  echo "<div class=\"errorbox\">
".$msg."
<div class=\"close\" onclick=\"this.parentNode.parentNode.removeChild(this.parentNode);\">&lt; schlie&szlig;en &gt;</div>
</div>
";
}

function confirm_out($msg) {
  echo "<div class=\"confirmbox\">
".$msg."
<div class=\"close\" onclick=\"this.parentNode.parentNode.removeChild(this.parentNode);\">&lt; schlie&szlig;en &gt;</div>
</div>
";
}

function login_out() {
  if (!is_file("password")) {
    $_SESSION["logged"] = true;
    if (!isset($_GET["mode"])) {
      $_GET["mode"] = "changepw";
    }
  } else if (isset($_SESSION["logged"]) && isset($_GET["logout"]) && $_GET["logout"] === "1") {
    unset($_SESSION["logged"]);
  }
  if (!isset($_SESSION["logged"])) {
    if (isset($_POST["passw"])) {
      if (check_passw($_POST["passw"])) {
        $_SESSION["logged"] = true;
        return true;
      } else {
        error_out("Falsches Passwort!");
      }
    }
    
    echo "<div class=\"password\">
<form action=\"".basename($_SERVER["SCRIPT_NAME"]);
    $dump = NULL;
    get_out($dump,array());
    echo "\" method=\"post\">
<div class=\"pwcenter\">
<label for=\"pw\">Passwort :</label>
<input class=\"inputtext\" type=\"password\" name=\"passw\" id=\"pw\">
<input class=\"button\" type=\"submit\" value=\"Anmelden\">
</div>
</form>
</div>
";
    return false;
  }
  return true;
}

function logout_out() {
  if (is_file("password")) {
    echo "<div class=\"divlogout\"><a class=\"abutton\" href=\"";
    $dump = NULL;
    get_out($dump,array("logout" => "1"));
    echo "\">Abmelden</a></div>
";
  }
}

function change_passw() {
  if ((!is_file("password") || isset($_POST["oldpw"])) && isset($_POST["newpw"]) && isset($_POST["confirm"])) {
    $_POST["newpw"] = trim($_POST["newpw"]);
    $_POST["confirm"] = trim($_POST["confirm"]);
    $l = strlen($_POST["newpw"]);
    if (is_file("password") && isset($_POST["oldpw"]) && !check_passw($_POST["oldpw"])) {
      error_out("Das alte Passwort ist falsch!");
    } else if ($_POST["newpw"] !== $_POST["confirm"]) {
      error_out("Das neue Passwort stimmt nicht mit der Wiederholung &uuml;berein!");
    } else if ($l < 3 || $l > 16) {
      error_out("Das neue Passwort muss zwischen 3 und 16 Zeichen lang sein!");
    } else {
      $h = fopen("password","wb");
      $new = md5($_POST["newpw"]);
      fwrite($h,$new,strlen($new));
      fclose($h);
      chmod("password",0600);
      confirm_out("Passwort ge&auml;ndert!");
    }
  }
  
  echo "<form action=\"".basename($_SERVER["SCRIPT_NAME"]);
  $submit = array("mode");
  get_out($submit,array());
  echo "\" method=\"post\">
<div class=\"topmenu\">
";
  
  if (is_file("password")) {
    echo "<div class=\"formrow\"><label for=\"oldpw\">Altes Passwort :</label><input class=\"inputtext\" type=\"password\" name=\"oldpw\" id=\"oldpw\"></div>
";
  }
  
  echo "<div class=\"formrow\"><label for=\"newpw\">Neues Passwort :</label><input class=\"inputtext\" type=\"password\" name=\"newpw\" id=\"newpw\"></div>
<div class=\"formrow\"><label for=\"confirm\">Wiederholung :</label><input class=\"inputtext\" type=\"password\" name=\"confirm\" id=\"confirm\"></div>
<div class=\"formrow\"><label for=\"save\"></label><input class=\"button\" type=\"submit\" id=\"save\" value=\"Speichern\"></div>
</div>
</form>
";
}

function hex_write(&$out,$byte) {
  $char = array("0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F");
  $out .= $char[ord($byte) >> 4].$char[ord($byte)%16];
}

function hex_write_int(&$out,$n,$bytes) {
  if ($bytes > 0) {
    hex_write_int($out,$n >> 8,$bytes-1);
    hex_write($out,chr($n%256));
  }
}

function hex_write_string(&$out,$str) {
  $n = strlen($str);
  hex_write_int($out,$n,2);
  for ($i = 0; $i < $n; $i++) {
    hex_write($out,$str[$i]);
  }
}

function &load_codes(&$type,&$data) {
  $codes = array();
  for ($j = 0; $j < $data["columns"]; $j++) {
    $h = fopen("show/".$type[$j]["2"].".show","rb");
    $codes[$j] = fread($h,filesize("show/".$type[$j]["2"].".show"));
    fclose($h);
  }
  return $codes;
}

function table_write(&$data,$status,&$type,$pos) {
  $out = "";
  hex_write($out,chr($status));
  if ($status == 0) {
    hex_write_int($out,$pos,4);
  }
  hex_write_int($out,$data["columns"],4);
  $n = count($data["table"]);
  hex_write_int($out,$n,4);
  
  for ($i = 0; $i < $data["columns"]; $i++) {
    hex_write_string($out,$data["col".$i]);
  }
  
  $codes = load_codes($type,$data);
  
  for ($i = 0; $i < $n; $i++) {
    for ($j = 0; $j < $data["columns"]; $j++) {
      $row = $i+1;
      $value = $data["table"][$i][$j];
      hex_write_string($out,eval($codes[$j]));
    }
  }
  echo $out;
}

function submit(&$data,&$type,&$pos) {
  if (!check_table($data,false)) {
    return 4;
  }
  $type = array();
  $check = "";
  $m = count($data["table"]);
  $equal = false;
  $equal_c = 0;
  for ($i = 0; $i < $data["columns"]; $i++) {
    $type[$i] = db_read_file("type/".$data["type".$i].".type");
    if (!check_type($type[$i],false)) {
      return 4;
    }
  }
  for ($i = 0; $i < $data["columns"]; $i++) {
    if ($type[$i]["0"] == 0) {
      if (!isset($_GET["col".$i])) {
        return 1;
      } else {
        $value = $_GET["col".$i];
        if ($type[$i]["1"] != "") {
          $h = fopen("filter/".$type[$i]["1"].".filter","rb");
          $code = fread($h,filesize("filter/".$type[$i]["1"].".filter"));
          fclose($h);
          if (!eval($code)) {
            return 1;
          }
        }
        if ($equal === false) {
          $equal = array();
          for ($j = 0; $j < $m; $j++) {
            if ($data["table"][$j][$i] == $value) {
              $equal[] = $j;
              $equal_c++;
            }
          }
        } else {
          for ($j = 0; $j < $equal_c; $j++) {
            if ($data["table"][$equal[$j]][$i] != $value) {
              array_splice($equal,$j,1);
              $equal_c--;
              $j--;
            }
          }
        }
        $check .= strlen($_GET["col".$i])."-".$_GET["col".$i]."-";
      }
    }
  }
  $check .= $data["passw"];
  if (md5($check) !== $_GET["key"]) {
    return 2;
  }
  if ($equal_c > 0) {
    $pos = $equal[0]+1;
    return 0;
  }
  
  $new = array();
  for ($i = 0; $i < $data["columns"]; $i++) {
    switch ($type[$i]["0"]) {
      case 0 :
        $new[] = $_GET["col".$i];
        break;
      case 1 :
        $h = fopen("auto/".$type[$i]["3"].".auto","rb");
        $new[] = eval(fread($h,filesize("auto/".$type[$i]["3"].".auto")));
        fclose($h);
        break;
      case 2 :
        $new[] = "";
        break;
    }
  }
  
  $codes = get_codes($data,$type);
  
  $pos = get_insert_row($data,$new,$codes);
  array_splice($data["table"],$pos,0,array($new));
  array_splice($data["table"],$data["numb"]);
  
  if ($pos < $data["numb"]) {
    db_write_file("table/".$_GET["name"].".table",$data);
    $pos++;
  } else {
    $pos = 0;
  }
  return 0;
}

?>