<?php

include "file.php";
include "function.php";

slashes();

if (isset($_GET["name"])) {
  $_GET["name"] = basename($_GET["name"]);
  if (!is_file("table/".$_GET["name"].".table") || ($data = db_read_file("table/".$_GET["name"].".table")) === false) {
    $out = "";
    hex_write($out,chr(3));
    echo $out;
  } else {
    $pos = 0;
    $status = submit($data,$type,$pos);
    if ($status == 4) {
      $out = "";
      hex_write($out,chr($status));
      echo $out;
    } else {
      table_write($data,$status,$type,$pos);
    }
  }
} else {
  $out = "";
  hex_write($out,chr(3));
  echo $out;
}

?>